import { pgTable, text, serial, integer, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users schema for login
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name"),
  email: text("email"),
  role: text("role").default("student"),
  createdAt: timestamp("created_at").defaultNow()
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  fullName: true,
  email: true,
  role: true
});

// Contact form schema
export const contacts = pgTable("contacts", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  message: text("message").notNull(),
  createdAt: timestamp("created_at").defaultNow()
});

export const contactSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters." }),
  email: z.string().email({ message: "Please enter a valid email address." }),
  phone: z.string().min(10, { message: "Please enter a valid phone number." }),
  message: z.string().min(10, { message: "Message must be at least 10 characters." })
});

export const insertContactSchema = createInsertSchema(contacts).pick({
  name: true,
  email: true,
  phone: true,
  message: true
});

// Admission form schema
export const admissions = pgTable("admissions", {
  id: serial("id").primaryKey(),
  fullName: text("full_name").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  parentPhone: text("parent_phone").notNull(),
  address: text("address").notNull(),
  currentSchool: text("current_school").notNull(),
  currentClass: text("current_class").notNull(),
  examType: text("exam_type").notNull(),
  batchType: text("batch_type").notNull(),
  subjects: jsonb("subjects").notNull(),
  additionalInfo: text("additional_info"),
  status: text("status").default("pending"),
  createdAt: timestamp("created_at").defaultNow()
});

export const admissionSchema = z.object({
  fullName: z.string().min(2, { message: "Full name must be at least 2 characters." }),
  email: z.string().email({ message: "Please enter a valid email address." }),
  phone: z.string().min(10, { message: "Please enter a valid phone number." }),
  parentPhone: z.string().min(10, { message: "Please enter a valid parent's phone number." }),
  address: z.string().min(10, { message: "Address must be at least 10 characters." }),
  currentSchool: z.string().min(2, { message: "Current school name is required." }),
  currentClass: z.string({ required_error: "Please select your current class." }),
  examType: z.enum(["iit-jee", "neet"], { required_error: "Please select an exam type." }),
  batchType: z.enum(["foundation", "target"], { required_error: "Please select a batch type." }),
  subjects: z.string().array().min(1, { message: "Please select at least one subject." }),
  additionalInfo: z.string().optional()
});

export const insertAdmissionSchema = createInsertSchema(admissions).pick({
  fullName: true,
  email: true,
  phone: true,
  parentPhone: true,
  address: true,
  currentSchool: true,
  currentClass: true,
  examType: true,
  batchType: true,
  subjects: true,
  additionalInfo: true,
  status: true
});

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Contact = typeof contacts.$inferSelect;
export type InsertContact = z.infer<typeof contactSchema>;

export type Admission = typeof admissions.$inferSelect;
export type InsertAdmission = z.infer<typeof admissionSchema>;
