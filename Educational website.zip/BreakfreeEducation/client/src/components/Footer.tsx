import { Link } from "wouter";
import { CONTACT } from "@/lib/constants";

const Footer = () => {
  return (
    <footer className="bg-neutral-900 text-white pt-12 pb-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Logo and About */}
          <div>
            <div className="flex items-center">
              <span className="font-montserrat font-bold text-2xl text-white">BreakFree Classes</span>
            </div>
            <p className="mt-4 text-neutral-400">
              Helping students achieve their dreams of entering premier institutes through quality education and guidance.
            </p>
            <div className="mt-6 flex space-x-4">
              <a href={`https://instagram.com/${CONTACT.instagram}`} target="_blank" rel="noopener noreferrer" className="text-neutral-400 hover:text-white">
                <i className="fab fa-instagram"></i>
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold font-montserrat">Quick Links</h3>
            <ul className="mt-4 space-y-2">
              <li><Link href="/" className="text-neutral-400 hover:text-white">Home</Link></li>
              <li><Link href="/about" className="text-neutral-400 hover:text-white">About Us</Link></li>
              <li><Link href="/admission" className="text-neutral-400 hover:text-white">Courses</Link></li>
              <li><Link href="/notes" className="text-neutral-400 hover:text-white">Notes</Link></li>
              <li><Link href="/assignments" className="text-neutral-400 hover:text-white">Assignments</Link></li>
              <li><Link href="/contact" className="text-neutral-400 hover:text-white">Contact</Link></li>
            </ul>
          </div>

          {/* Courses */}
          <div>
            <h3 className="text-lg font-semibold font-montserrat">Our Programs</h3>
            <ul className="mt-4 space-y-2">
              <li><Link href="/admission" className="text-neutral-400 hover:text-white">IIT JEE Foundation</Link></li>
              <li><Link href="/admission" className="text-neutral-400 hover:text-white">IIT JEE Target Batch</Link></li>
              <li><Link href="/admission" className="text-neutral-400 hover:text-white">NEET Foundation</Link></li>
              <li><Link href="/admission" className="text-neutral-400 hover:text-white">NEET Target Batch</Link></li>
              <li><Link href="/admission" className="text-neutral-400 hover:text-white">Physics Special</Link></li>
              <li><Link href="/admission" className="text-neutral-400 hover:text-white">Chemistry Special</Link></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-lg font-semibold font-montserrat">Contact Information</h3>
            <ul className="mt-4 space-y-2">
              {CONTACT.branches.map((branch, index) => (
                <li key={index} className="flex items-start">
                  <i className="fas fa-map-marker-alt mt-1 mr-2 text-neutral-400"></i>
                  <span className="text-neutral-400">{branch.name}: {branch.address}</span>
                </li>
              ))}
              <li className="flex items-start">
                <i className="fas fa-phone mt-1 mr-2 text-neutral-400"></i>
                <span className="text-neutral-400">{CONTACT.phone}</span>
              </li>
              <li className="flex items-start">
                <i className="fas fa-clock mt-1 mr-2 text-neutral-400"></i>
                <span className="text-neutral-400">{CONTACT.openingHours}</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-neutral-800 text-center">
          <p className="text-neutral-400">
            &copy; {new Date().getFullYear()} BreakFree Classes. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
