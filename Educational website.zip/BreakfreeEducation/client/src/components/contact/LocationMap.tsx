import { useEffect, useRef } from 'react';
import L from 'leaflet';

interface Branch {
  name: string;
  address: string;
  coordinates: [number, number];
}

interface LocationMapProps {
  branches: Branch[];
}

const LocationMap = ({ branches }: LocationMapProps) => {
  const mapRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!mapRef.current) return;

    // Check if a map is already initialized on the div
    if ((mapRef.current as any)._leaflet_id) {
      return;
    }

    const map = L.map(mapRef.current).setView([28.6139, 77.2090], 11); // Delhi coordinates as default

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);

    const bounds = L.latLngBounds([]);

    branches.forEach((branch) => {
      const marker = L.marker(branch.coordinates)
        .addTo(map)
        .bindPopup(`<b>${branch.name}</b><br>${branch.address}`);
      
      bounds.extend(branch.coordinates);
    });

    if (branches.length > 1) {
      map.fitBounds(bounds, {
        padding: [50, 50]
      });
    } else if (branches.length === 1) {
      map.setView(branches[0].coordinates, 15);
    }

    return () => {
      map.remove();
    };
  }, [branches]);

  return (
    <div ref={mapRef} className="h-64 bg-neutral-200 rounded-lg overflow-hidden"></div>
  );
};

export default LocationMap;
