import LocationMap from "./LocationMap";

interface ContactInfoProps {
  phone: string;
  branches: Array<{
    name: string;
    address: string;
    coordinates: [number, number];
  }>;
  instagram: string;
  openingHours?: string;
}

const ContactInfo = ({ phone, branches, instagram, openingHours }: ContactInfoProps) => {
  return (
    <div className="bg-neutral-100 p-6 rounded-lg shadow-sm">
      <h3 className="text-xl font-semibold text-neutral-900 font-montserrat mb-6">Get in Touch</h3>
      <div className="space-y-4">
        <div className="flex items-start">
          <div className="flex-shrink-0 h-10 w-10 rounded-full bg-primary flex items-center justify-center">
            <i className="fas fa-phone text-white"></i>
          </div>
          <div className="ml-4">
            <h4 className="text-lg font-medium text-neutral-900">Phone</h4>
            <p className="text-neutral-600">{phone}</p>
          </div>
        </div>
        
        {branches.map((branch, index) => (
          <div key={index} className="flex items-start">
            <div className="flex-shrink-0 h-10 w-10 rounded-full bg-primary flex items-center justify-center">
              <i className="fas fa-map-marker-alt text-white"></i>
            </div>
            <div className="ml-4">
              <h4 className="text-lg font-medium text-neutral-900">{branch.name}</h4>
              <p className="text-neutral-600">{branch.address}</p>
            </div>
          </div>
        ))}
        
        {openingHours && (
          <div className="flex items-start">
            <div className="flex-shrink-0 h-10 w-10 rounded-full bg-primary flex items-center justify-center">
              <i className="fas fa-clock text-white"></i>
            </div>
            <div className="ml-4">
              <h4 className="text-lg font-medium text-neutral-900">Opening Hours</h4>
              <p className="text-neutral-600">{openingHours}</p>
            </div>
          </div>
        )}
        
        <div className="flex items-start">
          <div className="flex-shrink-0 h-10 w-10 rounded-full bg-primary flex items-center justify-center">
            <i className="fab fa-instagram text-white"></i>
          </div>
          <div className="ml-4">
            <h4 className="text-lg font-medium text-neutral-900">Instagram</h4>
            <a href={`https://instagram.com/${instagram}`} target="_blank" rel="noopener noreferrer" className="text-primary hover:text-primary-dark">
              @{instagram}
            </a>
          </div>
        </div>
      </div>
      
      {/* Map */}
      <div className="mt-8">
        <LocationMap branches={branches} />
      </div>
    </div>
  );
};

export default ContactInfo;
