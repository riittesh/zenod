import React from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

interface HeroSectionProps {
  title: string | React.ReactNode;
  subtitle?: string;
  description?: string;
  imageUrl: string;
  showButtons?: boolean;
}

const HeroSection = ({ title, subtitle, description, imageUrl, showButtons = true }: HeroSectionProps) => {
  return (
    <section className="relative bg-primary overflow-hidden pt-16">
      <div className="absolute inset-0 z-0 opacity-10">
        <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: `url('https://images.unsplash.com/photo-1588072432836-e10032774350?auto=format&fit=crop&q=80')` }}></div>
      </div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div>
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white font-montserrat leading-tight">
              {title}
            </h1>
            {subtitle && (
              <p className="mt-4 text-xl text-white font-light">
                {subtitle}
              </p>
            )}
            <h2 className="mt-2 text-2xl sm:text-3xl font-semibold text-white">
              Specialist for <span className="text-accent">IIT JEE</span> and <span className="text-accent">NEET</span>
            </h2>
            {description && (
              <p className="mt-6 text-white text-lg max-w-lg">
                {description}
              </p>
            )}
            {showButtons && (
              <div className="mt-8 flex flex-wrap gap-4">
                <Button asChild variant="secondary" className="bg-white text-primary hover:bg-neutral-100">
                  <Link href="/admission">
                    Explore Courses
                  </Link>
                </Button>
                <Button asChild className="bg-secondary hover:bg-secondary-dark text-white">
                  <Link href="/admission">
                    Apply Now
                  </Link>
                </Button>
              </div>
            )}
          </div>
          <div className="flex justify-center">
            <div className="relative w-full max-w-md rounded-xl overflow-hidden shadow-2xl">
              <img 
                src={imageUrl}
                alt="Students studying" 
                className="rounded-xl object-cover object-center w-full h-auto md:h-96"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
