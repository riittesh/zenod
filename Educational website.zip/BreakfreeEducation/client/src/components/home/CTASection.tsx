import { Link } from "wouter";
import { Button } from "@/components/ui/button";

const CTASection = () => {
  return (
    <section className="relative py-16 bg-primary">
      <div className="absolute inset-0 opacity-10 bg-[url('https://images.unsplash.com/photo-1523050854058-8df90110c9f1?auto=format&fit=crop&q=80')] bg-cover bg-center"></div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-white font-montserrat">Ready to Excel in Your Entrance Exams?</h2>
          <p className="mt-4 text-lg text-white max-w-2xl mx-auto">
            Join Numerical Expert today and take the first step towards your dream college.
          </p>
          <div className="mt-8 flex justify-center flex-wrap gap-4">
            <Button asChild variant="secondary" className="bg-white text-primary hover:bg-neutral-100">
              <Link href="/admission">
                View Courses
              </Link>
            </Button>
            <Button asChild className="bg-secondary hover:bg-secondary-dark text-white">
              <Link href="/admission">
                Apply Now
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CTASection;
