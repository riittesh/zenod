import { Link } from "wouter";

interface CourseCardProps {
  type: "iit" | "neet";
  title: string;
  subjects: string[];
}

const CourseCard = ({ type, title, subjects }: CourseCardProps) => {
  const isIIT = type === "iit";
  const gradientColors = isIIT ? "from-primary to-primary-dark" : "from-secondary to-secondary-dark";
  const iconClass = isIIT ? "fas fa-atom" : "fas fa-heartbeat";
  const textColor = isIIT ? "text-primary" : "text-secondary";
  const badgeColor = isIIT ? "bg-white text-primary" : "bg-white text-secondary";
  const buttonColor = isIIT ? "text-primary" : "text-secondary";

  return (
    <div className="relative rounded-xl overflow-hidden">
      <div className={`absolute inset-0 bg-gradient-to-r ${gradientColors} opacity-90`}></div>
      <div className="relative p-8">
        <div className="flex justify-between items-start">
          <div>
            <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${badgeColor}`}>
              Foundation & Target Batches
            </span>
            <h3 className="mt-4 text-2xl font-bold text-white font-montserrat">{title}</h3>
          </div>
          <div className="h-16 w-16 rounded-full bg-white flex items-center justify-center flex-shrink-0 border-4 border-white">
            <i className={`${iconClass} ${textColor} text-2xl`}></i>
          </div>
        </div>
        <div className="mt-4 space-y-4">
          {subjects.map((subject, index) => (
            <div key={index} className="flex items-center">
              <i className="fas fa-check-circle text-white mr-2"></i>
              <p className="text-white">{subject}</p>
            </div>
          ))}
        </div>
        <div className="mt-8">
          <Link href="/admission" className={`inline-flex items-center px-5 py-2 border border-transparent text-base font-medium rounded-md shadow-sm ${buttonColor} bg-white hover:bg-neutral-100 focus:outline-none`}>
            Learn More
            <i className="fas fa-arrow-right ml-2"></i>
          </Link>
        </div>
      </div>
    </div>
  );
};

const CoursesSection = () => {
  return (
    <section className="py-16 bg-neutral-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-neutral-900 font-montserrat">Our Specialized Programs</h2>
          <p className="mt-4 text-lg text-neutral-600 max-w-2xl mx-auto">
            Choose the right program tailored to your academic goals and needs.
          </p>
        </div>

        <div className="mt-12 grid grid-cols-1 gap-8 md:grid-cols-2">
          <CourseCard 
            type="iit" 
            title="IIT JEE Preparation"
            subjects={[
              "Physics: Mechanics, Electromagnetism, Modern Physics",
              "Chemistry: Physical, Organic, Inorganic",
              "Mathematics: Algebra, Calculus, Coordinate Geometry"
            ]}
          />
          <CourseCard 
            type="neet" 
            title="NEET Preparation"
            subjects={[
              "Physics: Mechanics, Thermodynamics, Optics",
              "Chemistry: Physical, Organic, Inorganic",
              "Biology: Botany, Zoology, Human Physiology"
            ]}
          />
        </div>
      </div>
    </section>
  );
};

export default CoursesSection;
