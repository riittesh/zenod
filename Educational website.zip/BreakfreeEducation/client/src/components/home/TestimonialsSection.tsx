interface TestimonialProps {
  quote: string;
  name: string;
  institution: string;
  initials: string;
  bgColor: string;
}

const Testimonial = ({ quote, name, institution, initials, bgColor }: TestimonialProps) => {
  return (
    <div className="bg-neutral-100 rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow">
      <div className="flex items-center mb-4">
        <div className="text-accent">
          <i className="fas fa-star"></i>
          <i className="fas fa-star"></i>
          <i className="fas fa-star"></i>
          <i className="fas fa-star"></i>
          <i className="fas fa-star"></i>
        </div>
      </div>
      <p className="text-neutral-600 italic">
        {quote}
      </p>
      <div className="mt-6 flex items-center">
        <div className={`flex-shrink-0 h-10 w-10 rounded-full ${bgColor} flex items-center justify-center`}>
          <span className="text-white font-medium">{initials}</span>
        </div>
        <div className="ml-3">
          <h4 className="text-sm font-medium text-neutral-900">{name}</h4>
          <p className="text-sm text-neutral-500">{institution}</p>
        </div>
      </div>
    </div>
  );
};

const TestimonialsSection = () => {
  const testimonials = [
    {
      quote: "The numerical problem-solving techniques taught here helped me tackle even the most challenging questions in JEE Advanced. I secured AIR 342 thanks to the guidance from Numerical Expert.",
      name: "Rahul Agarwal",
      institution: "IIT Delhi, 2023 Batch",
      initials: "RA",
      bgColor: "bg-primary-light"
    },
    {
      quote: "The biology sessions were excellent with detailed explanations and visual aids. The regular tests helped me identify my weak areas and improve consistently. Got 650+ in NEET 2023.",
      name: "Priya Mehta",
      institution: "AIIMS Delhi, 2023 Batch",
      initials: "PM",
      bgColor: "bg-secondary-light"
    },
    {
      quote: "The foundation course completely transformed my approach to Physics problems. The faculty's focus on conceptual clarity rather than rote learning made a huge difference in my performance.",
      name: "Amit Kumar",
      institution: "NIT Trichy, 2023 Batch",
      initials: "AK",
      bgColor: "bg-primary-light"
    }
  ];

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-neutral-900 font-montserrat">What Our Students Say</h2>
          <p className="mt-4 text-lg text-neutral-600 max-w-2xl mx-auto">
            Hear from our students who have achieved success through our coaching programs.
          </p>
        </div>

        <div className="mt-12">
          <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
            {testimonials.map((testimonial, index) => (
              <Testimonial key={index} {...testimonial} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
