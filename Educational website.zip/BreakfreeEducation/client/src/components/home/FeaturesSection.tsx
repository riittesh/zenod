interface FeatureProps {
  icon: string;
  title: string;
  description: string;
}

const Feature = ({ icon, title, description }: FeatureProps) => {
  return (
    <div className="relative rounded-lg border border-neutral-200 bg-white p-6 shadow-sm flex flex-col items-center text-center hover:shadow-md transition-shadow">
      <div className="h-16 w-16 rounded-full bg-primary-light flex items-center justify-center mb-4">
        <i className={`${icon} text-white text-2xl`}></i>
      </div>
      <h3 className="text-xl font-semibold text-neutral-900 font-montserrat">{title}</h3>
      <p className="mt-3 text-neutral-600">
        {description}
      </p>
    </div>
  );
};

const FeaturesSection = () => {
  const features = [
    {
      icon: "fas fa-chalkboard-teacher",
      title: "Experienced Faculty",
      description: "Learn from experienced educators specialized in preparing students for IIT JEE and NEET examinations."
    },
    {
      icon: "fas fa-book-open",
      title: "Comprehensive Study Material",
      description: "Access to detailed notes, assignments, and practice problems designed to strengthen concepts."
    },
    {
      icon: "fas fa-chart-line",
      title: "Regular Performance Analysis",
      description: "Track progress through regular tests and personalized feedback to improve weak areas."
    }
  ];

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-neutral-900 font-montserrat">Why Choose Numerical Expert?</h2>
          <p className="mt-4 text-lg text-neutral-600 max-w-2xl mx-auto">
            Our coaching program is designed to help students develop a strong foundation and excel in competitive exams.
          </p>
        </div>

        <div className="mt-12 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((feature, index) => (
            <Feature key={index} {...feature} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;
