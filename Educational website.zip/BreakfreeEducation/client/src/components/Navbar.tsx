import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";

const Navbar = () => {
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const links = [
    { name: "Home", path: "/" },
    { name: "Admission", path: "/admission" },
    { name: "Notes", path: "/notes" },
    { name: "Assignments", path: "/assignments" },
    { name: "About Us", path: "/about" },
    { name: "Contact", path: "/contact" }
  ];

  const toggleMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  return (
    <nav className="bg-white shadow-md fixed w-full top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex-shrink-0 flex items-center">
            {/* Logo */}
            <Link href="/" className="flex items-center">
              <span className="font-montserrat font-bold text-2xl text-primary">BreakFree Classes</span>
            </Link>
          </div>

          {/* Mobile menu button */}
          <div className="flex items-center -mr-2 sm:hidden">
            <button
              type="button"
              onClick={toggleMenu}
              className="inline-flex items-center justify-center p-2 rounded-md text-neutral-400 hover:text-neutral-500 hover:bg-neutral-100 focus:outline-none"
            >
              <span className="sr-only">Open main menu</span>
              <i className="fa fa-bars text-xl"></i>
            </button>
          </div>

          {/* Desktop menu */}
          <div className="hidden sm:ml-6 sm:flex sm:space-x-6 items-center">
            {links.map((link) => (
              <Link
                key={link.path}
                href={link.path}
                className={`${
                  location === link.path
                    ? "border-primary text-primary"
                    : "border-transparent text-neutral-500 hover:border-neutral-300 hover:text-neutral-700"
                } border-b-2 px-1 pt-1 font-medium`}
              >
                {link.name}
              </Link>
            ))}
            <Link
              href="/login"
              className="border-transparent text-neutral-500 hover:border-neutral-300 hover:text-neutral-700 px-1 pt-1 border-b-2 font-medium"
            >
              Login
            </Link>
            <Button asChild className="ml-2 bg-secondary hover:bg-secondary-dark text-white">
              <Link href="/admission">
                Apply Now
              </Link>
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      <div className={`sm:hidden ${mobileMenuOpen ? "block" : "hidden"}`}>
        <div className="pt-2 pb-3 space-y-1">
          {links.map((link) => (
            <Link
              key={link.path}
              href={link.path}
              className={`${
                location === link.path
                  ? "bg-primary-light text-white"
                  : "text-neutral-500 hover:bg-neutral-100 hover:text-neutral-800"
              } block pl-3 pr-4 py-2 text-base font-medium`}
              onClick={() => setMobileMenuOpen(false)}
            >
              {link.name}
            </Link>
          ))}
          <Link
            href="/login"
            className="text-neutral-500 hover:bg-neutral-100 hover:text-neutral-800 block pl-3 pr-4 py-2 text-base font-medium"
            onClick={() => setMobileMenuOpen(false)}
          >
            Login
          </Link>
          <div className="px-2 py-2">
            <Button asChild className="w-full bg-secondary hover:bg-secondary-dark text-white">
              <Link href="/admission" onClick={() => setMobileMenuOpen(false)}>
                Apply Now
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
