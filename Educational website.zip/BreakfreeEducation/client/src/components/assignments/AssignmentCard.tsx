import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

interface AssignmentCardProps {
  title: string;
  subject: string;
  dueDate: string;
  type: "homework" | "classwork";
  googleClassroomLink: string;
}

const AssignmentCard = ({ title, subject, dueDate, type, googleClassroomLink }: AssignmentCardProps) => {
  const subjectIcons: Record<string, string> = {
    "Physics": "fas fa-atom",
    "Chemistry": "fas fa-flask",
    "Mathematics": "fas fa-square-root-alt",
    "Biology": "fas fa-dna",
  };

  const subjectColors: Record<string, string> = {
    "Physics": "text-blue-600",
    "Chemistry": "text-purple-600",
    "Mathematics": "text-green-600",
    "Biology": "text-red-600",
  };

  const badgeColors: Record<string, string> = {
    "homework": "bg-yellow-100 text-yellow-800",
    "classwork": "bg-blue-100 text-blue-800",
  };

  const icon = subjectIcons[subject] || "fas fa-book";
  const color = subjectColors[subject] || "text-gray-600";
  const badgeColor = badgeColors[type] || "bg-gray-100 text-gray-800";

  return (
    <Card className="overflow-hidden hover:shadow-md transition-all duration-200">
      <CardContent className="pt-6">
        <div className="flex justify-between items-start mb-4">
          <div className="flex items-center">
            <div className="mr-3 text-2xl">
              <i className={`${icon} ${color}`}></i>
            </div>
            <div>
              <h3 className="font-montserrat font-bold">{title}</h3>
              <p className="text-sm text-neutral-600">{subject}</p>
            </div>
          </div>
          <Badge className={badgeColor}>
            {type === "homework" ? "Homework" : "Classwork"}
          </Badge>
        </div>
        
        <div className="flex items-center text-sm text-neutral-600 mt-2">
          <i className="far fa-calendar-alt mr-2"></i>
          <span>Due: {dueDate}</span>
        </div>
      </CardContent>
      
      <CardFooter className="border-t pt-4">
        <Button asChild variant="outline" className="w-full">
          <a href={googleClassroomLink} target="_blank" rel="noopener noreferrer">
            <i className="fab fa-google mr-2"></i> Open in Google Classroom
          </a>
        </Button>
      </CardFooter>
    </Card>
  );
};

export default AssignmentCard;
