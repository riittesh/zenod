import { Link } from "wouter";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

interface SubjectCardProps {
  title: string;
  description: string;
  icon: string;
  category: "iit" | "neet";
  chapters: string[];
  href: string;
}

const SubjectCard = ({ title, description, icon, category, chapters, href }: SubjectCardProps) => {
  const categoryColor = category === "iit" ? "bg-primary" : "bg-secondary";
  
  return (
    <Card className="overflow-hidden transition-all duration-200 hover:shadow-lg">
      <div className="p-4 flex items-center space-x-4">
        <div className={`h-12 w-12 rounded-full ${categoryColor} flex items-center justify-center`}>
          <i className={`${icon} text-white text-xl`}></i>
        </div>
        <div>
          <h3 className="font-montserrat font-bold text-lg">{title}</h3>
          <Badge variant="outline" className={`${category === "iit" ? "text-primary" : "text-secondary"}`}>
            {category === "iit" ? "IIT JEE" : "NEET"}
          </Badge>
        </div>
      </div>
      <CardContent>
        <p className="text-neutral-600 mb-4">{description}</p>
        <div className="space-y-1">
          <p className="font-medium text-sm">Key Chapters:</p>
          <ul className="text-sm text-neutral-600 space-y-1">
            {chapters.map((chapter, index) => (
              <li key={index} className="flex items-start">
                <i className="fas fa-check-circle text-green-500 mr-2 mt-1 flex-shrink-0"></i>
                <span>{chapter}</span>
              </li>
            ))}
          </ul>
        </div>
      </CardContent>
      <CardFooter className="border-t pt-4">
        <Button asChild className={`w-full ${category === "iit" ? "bg-primary hover:bg-primary-dark" : "bg-secondary hover:bg-secondary-dark"}`}>
          <Link href={href}>
            View Notes <i className="fas fa-arrow-right ml-2"></i>
          </Link>
        </Button>
      </CardFooter>
    </Card>
  );
};

export default SubjectCard;
