import { Card, CardContent } from "@/components/ui/card";

interface QRCodeProps {
  title: string;
  description: string;
  qrCodeUrl: string;
  instructions?: string[];
  upiId?: string;
}

const QRCode = ({ title, description, qrCodeUrl, instructions = [], upiId }: QRCodeProps) => {
  return (
    <Card className="max-w-md mx-auto overflow-hidden">
      <CardContent className="p-6 flex flex-col items-center">
        <h2 className="text-2xl font-bold text-center font-montserrat mb-4">{title}</h2>
        <p className="text-neutral-600 text-center mb-6">{description}</p>
        
        <div className="bg-white p-4 rounded-lg shadow-sm border mb-6">
          <img 
            src={qrCodeUrl} 
            alt="Payment QR Code" 
            className="w-full max-w-xs h-auto mx-auto"
          />
          {upiId && (
            <p className="text-center mt-3 text-primary font-medium">
              UPI ID: {upiId}
            </p>
          )}
        </div>
        
        {instructions.length > 0 && (
          <div className="w-full">
            <h3 className="font-medium mb-2">How to pay:</h3>
            <ol className="list-decimal pl-5 space-y-1 text-neutral-600">
              {instructions.map((instruction, index) => (
                <li key={index}>{instruction}</li>
              ))}
            </ol>
          </div>
        )}
        
        <div className="mt-6 bg-yellow-50 p-3 rounded-md text-sm text-yellow-800 w-full">
          <p className="flex items-center">
            <i className="fas fa-info-circle mr-2"></i>
            After payment, please take a screenshot of the transaction and send it to us via WhatsApp for confirmation.
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default QRCode;
