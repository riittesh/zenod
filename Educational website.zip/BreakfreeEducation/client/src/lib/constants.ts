export const SITE_NAME = "BreakFree Classes";
export const SITE_DESCRIPTION = "Over 8+ Years of Excellence in Teaching. Specialist for IIT JEE and NEET.";

export const CONTACT = {
  phone: "+91 7325088255",
  instagram: "break.freeclasses",
  branches: [
    {
      name: "Branch 1",
      address: "Aryan Photocopy, Maranpur, Gaya",
      coordinates: [24.7914, 85.0002] as [number, number], // Gaya coordinates
    },
    {
      name: "Branch 2",
      address: "Infront of Project Kanya, High School",
      coordinates: [24.7951, 85.0100] as [number, number], // Different Gaya area coordinates
    }
  ],
  openingHours: "Everyday from 9 AM to 9 PM"
};

export const SUBJECT_TYPES = {
  IIT_JEE: {
    PHYSICS: {
      title: "Physics",
      icon: "fas fa-atom",
      description: "Master the concepts of mechanics, electromagnetism, thermodynamics, and modern physics.",
      chapters: [
        "Kinematics",
        "Laws of Motion",
        "Work, Energy, and Power",
        "Rotational Motion",
        "Gravitation",
        "Properties of Matter",
        "Thermodynamics",
        "Kinetic Theory of Gases",
        "Oscillations and Waves",
        "Electrostatics",
        "Current Electricity",
        "Magnetic Effects of Current and Magnetism",
        "Electromagnetic Induction and Alternating Currents",
        "Optics",
        "Modern Physics"
      ]
    },
    CHEMISTRY: {
      title: "Chemistry",
      icon: "fas fa-flask",
      description: "Comprehensive coverage of physical, organic, and inorganic chemistry for JEE exams.",
      chapters: [
        "Some Basic Concepts of Chemistry",
        "States of Matter",
        "Atomic Structure",
        "Chemical Bonding and Molecular Structure",
        "Thermodynamics",
        "Equilibrium",
        "Redox Reactions",
        "The Solid State",
        "Solutions",
        "Electrochemistry",
        "Chemical Kinetics",
        "Surface Chemistry",
        "The Periodic Table and Periodicity in Properties",
        "Hydrogen",
        "The s-, p-, d-, and f-Block Elements",
        "Coordination Compounds",
        "Organic Chemistry – Basic Principles",
        "Hydrocarbons",
        "Alcohols, Phenols, and Ethers",
        "Aldehydes, Ketones, and Carboxylic Acids",
        "Amines",
        "Biomolecules",
        "Polymers",
        "Environmental Chemistry"
      ]
    },
    MATHEMATICS: {
      title: "Mathematics",
      icon: "fas fa-square-root-alt",
      description: "Strengthen your mathematical foundation with algebra, calculus, and geometry.",
      chapters: [
        "Sets, Relations, and Functions",
        "Complex Numbers and Quadratic Equations",
        "Matrices and Determinants",
        "Permutations and Combinations",
        "Binomial Theorem",
        "Sequence and Series",
        "Limits, Continuity, and Differentiability",
        "Integral Calculus",
        "Differential Equations",
        "Coordinate Geometry",
        "Three-Dimensional Geometry",
        "Vector Algebra",
        "Statistics and Probability",
        "Trigonometry",
        "Mathematical Reasoning"
      ]
    }
  },
  NEET: {
    PHYSICS: {
      title: "Physics",
      icon: "fas fa-atom",
      description: "Focused preparation for NEET physics with emphasis on numerical problems and concepts.",
      chapters: [
        "Physical World and Measurement",
        "Kinematics",
        "Laws of Motion",
        "Work, Energy, and Power",
        "Motion of System of Particles and Rigid Body",
        "Gravitation",
        "Properties of Bulk Matter",
        "Thermodynamics",
        "Behaviour of Perfect Gas and Kinetic Theory",
        "Oscillations and Waves",
        "Electrostatics",
        "Current Electricity",
        "Magnetic Effects of Current and Magnetism",
        "Electromagnetic Induction and Alternating Currents",
        "Electromagnetic Waves",
        "Optics",
        "Dual Nature of Matter and Radiation",
        "Atoms and Nuclei",
        "Electronic Devices"
      ]
    },
    CHEMISTRY: {
      title: "Chemistry",
      icon: "fas fa-flask",
      description: "Comprehensive study material covering all aspects of chemistry required for NEET.",
      chapters: [
        "Some Basic Concepts of Chemistry",
        "Structure of Atom",
        "Classification of Elements and Periodicity in Properties",
        "Chemical Bonding and Molecular Structure",
        "States of Matter",
        "Thermodynamics",
        "Equilibrium",
        "Redox Reactions",
        "The Solid State",
        "Solutions",
        "Electrochemistry",
        "Chemical Kinetics",
        "Surface Chemistry",
        "The s-, p-, d-, and f-Block Elements",
        "Coordination Compounds",
        "Organic Chemistry – Basic Principles",
        "Hydrocarbons",
        "Haloalkanes and Haloarenes",
        "Alcohols, Phenols, and Ethers",
        "Aldehydes, Ketones, and Carboxylic Acids",
        "Organic Compounds Containing Nitrogen",
        "Biomolecules",
        "Polymers",
        "Chemistry in Everyday Life"
      ]
    },
    BIOLOGY: {
      title: "Biology",
      icon: "fas fa-dna",
      description: "In-depth coverage of botany and zoology topics with detailed diagrams and explanations.",
      chapters: [
        "Diversity of the Living World",
        "Structural Organisation in Animals and Plants",
        "Cell Structure and Function",
        "Plant Physiology",
        "Human Physiology",
        "Reproduction",
        "Genetics and Evolution",
        "Biology and Human Welfare",
        "Biotechnology and Its Applications",
        "Ecology and Environment"
      ]
    }
  }
};

export const DIRECTOR_INFO = {
  name: "Sagar Manglam",
  title: "Director of BreakFree Classes",
  description: "With over 8 years of experience in teaching Physics, Chemistry, and Mathematics, Prof. Sagar Manglam has helped hundreds of students achieve their dreams of getting into top engineering and medical colleges. His unique approach to solving numerical problems has earned him recognition as one of the best coaches for IIT JEE and NEET preparation."
};

export const PAYMENT_INFO = {
  qrCodeUrl: "https://upload.wikimedia.org/wikipedia/commons/d/d0/QR_code_for_mobile_English_Wikipedia.svg", // Example QR code
  upiId: "breakfreeclasses@upi",
  instructions: [
    "Open any UPI app on your smartphone (PhonePe, Google Pay, BHIM, etc.)",
    "Scan the QR code shown above",
    "Enter the fee amount as communicated by the administration",
    "Complete the payment using your preferred UPI method",
    "Save the transaction receipt for your records"
  ]
};
