import QRCode from "@/components/payment/QRCode";
import HeroSection from "@/components/hero/HeroSection";
import { PAYMENT_INFO } from "@/lib/constants";
import { Helmet } from "react-helmet";
import { SITE_NAME } from "@/lib/constants";

const PaymentPage = () => {
  return (
    <>
      <Helmet>
        <title>Fee Payment - {SITE_NAME}</title>
        <meta name="description" content="Make secure fee payments to Numerical Expert coaching institute using UPI, online banking or cards." />
      </Helmet>

      <HeroSection
        title="Fee Payment"
        description="Secure and convenient payment options for your coaching fees."
        imageUrl="https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?auto=format&fit=crop&q=80"
        showButtons={false}
      />

      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-bold text-neutral-900 font-montserrat">Make a Payment</h2>
            <p className="mt-2 text-lg text-neutral-600 max-w-2xl mx-auto">
              Use the QR code below to make your fee payment through UPI.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-10 items-center">
            <QRCode
              title="Pay via UPI"
              description="Scan the QR code with any UPI app (Google Pay, PhonePe, Paytm, etc.) to make your payment."
              qrCodeUrl={PAYMENT_INFO.qrCodeUrl}
              instructions={PAYMENT_INFO.instructions}
              upiId={PAYMENT_INFO.upiId}
            />
            
            <div className="space-y-6">
              <div className="bg-white p-6 rounded-lg shadow-sm border border-neutral-200">
                <h3 className="text-xl font-semibold text-neutral-900 font-montserrat mb-4">Fee Structure</h3>
                <div className="space-y-4">
                  <div className="flex justify-between pb-2 border-b">
                    <span className="font-medium">Foundation Batch (Class 11)</span>
                    <span>₹45,000/year</span>
                  </div>
                  <div className="flex justify-between pb-2 border-b">
                    <span className="font-medium">Foundation Batch (Class 12)</span>
                    <span>₹48,000/year</span>
                  </div>
                  <div className="flex justify-between pb-2 border-b">
                    <span className="font-medium">Target Batch (IIT JEE)</span>
                    <span>₹65,000/year</span>
                  </div>
                  <div className="flex justify-between pb-2 border-b">
                    <span className="font-medium">Target Batch (NEET)</span>
                    <span>₹60,000/year</span>
                  </div>
                  <div className="flex justify-between pb-2 border-b">
                    <span className="font-medium">Subject Wise (Per Subject)</span>
                    <span>₹20,000/year</span>
                  </div>
                </div>
                <p className="mt-4 text-sm text-neutral-500">
                  * Fees can be paid in installments. Contact administration for details.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-sm border border-neutral-200">
                <h3 className="text-xl font-semibold text-neutral-900 font-montserrat mb-4">Other Payment Methods</h3>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-medium mb-1">Bank Transfer (NEFT/RTGS/IMPS)</h4>
                    <div className="pl-4 text-neutral-600 text-sm">
                      <p>Account Name: Numerical Expert</p>
                      <p>Account Number: XXXX XXXX XXXX 1234</p>
                      <p>IFSC Code: ABCD0001234</p>
                      <p>Bank: Example Bank</p>
                      <p>Branch: Main Branch</p>
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-medium mb-1">Cash Payment</h4>
                    <p className="text-neutral-600 text-sm pl-4">
                      Visit our center during office hours (9 AM - 6 PM) to make a cash payment.
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="bg-yellow-50 p-4 rounded-lg text-yellow-800 text-sm">
                <p className="flex items-start">
                  <i className="fas fa-info-circle mt-1 mr-2"></i>
                  <span>
                    <strong>Important:</strong> Please mention the student's name and registered phone number in the payment reference. After making the payment, please inform the administration for confirmation.
                  </span>
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default PaymentPage;
