import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import HeroSection from "@/components/hero/HeroSection";
import { Helmet } from "react-helmet";
import { SITE_NAME } from "@/lib/constants";

const formSchema = z.object({
  fullName: z.string().min(2, {
    message: "Full name must be at least 2 characters.",
  }),
  email: z.string().email({
    message: "Please enter a valid email address.",
  }),
  phone: z.string().min(10, {
    message: "Please enter a valid phone number.",
  }),
  parentPhone: z.string().min(10, {
    message: "Please enter a valid parent's phone number.",
  }),
  address: z.string().min(10, {
    message: "Address must be at least 10 characters.",
  }),
  currentSchool: z.string().min(2, {
    message: "Current school name is required.",
  }),
  currentClass: z.string({
    required_error: "Please select your current class.",
  }),
  examType: z.enum(["iit-jee", "neet"], {
    required_error: "Please select an exam type.",
  }),
  batchType: z.enum(["foundation", "target"], {
    required_error: "Please select a batch type.",
  }),
  subjects: z.string().array().min(1, {
    message: "Please select at least one subject.",
  }),
  additionalInfo: z.string().optional(),
});

type FormValues = z.infer<typeof formSchema>;

const AdmissionPage = () => {
  const { toast } = useToast();

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      fullName: "",
      email: "",
      phone: "",
      parentPhone: "",
      address: "",
      currentSchool: "",
      currentClass: "",
      examType: "iit-jee",
      batchType: "foundation",
      subjects: [],
      additionalInfo: "",
    },
  });

  const mutation = useMutation({
    mutationFn: async (values: FormValues) => {
      const res = await apiRequest("POST", "/api/admission", values);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Application Submitted Successfully!",
        description: "We will contact you shortly with further details.",
      });
      form.reset();
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Something went wrong. Please try again.",
      });
    },
  });

  const onSubmit = (values: FormValues) => {
    mutation.mutate(values);
  };

  return (
    <>
      <Helmet>
        <title>Admission - {SITE_NAME}</title>
        <meta name="description" content="Apply for admission to IIT JEE and NEET coaching programs at Numerical Expert." />
      </Helmet>

      <HeroSection
        title="Join Our Coaching Programs"
        description="Take the first step towards your dream college with our specialized preparation programs for IIT JEE and NEET."
        imageUrl="https://images.unsplash.com/photo-1523580494863-6f3031224c94?auto=format&fit=crop&q=80"
        showButtons={false}
      />

      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-bold text-neutral-900 font-montserrat">Admission Form</h2>
            <p className="mt-4 text-lg text-neutral-600">
              Fill out the form below to apply for admission to our coaching programs.
            </p>
          </div>

          <div className="bg-neutral-50 p-6 rounded-lg shadow-sm border border-neutral-200">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="fullName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Full Name</FormLabel>
                        <FormControl>
                          <Input placeholder="John Doe" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email Address</FormLabel>
                        <FormControl>
                          <Input placeholder="you@example.com" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Your Phone Number</FormLabel>
                        <FormControl>
                          <Input placeholder="+91 98765 43210" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="parentPhone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Parent's Phone Number</FormLabel>
                        <FormControl>
                          <Input placeholder="+91 98765 43210" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="address"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Address</FormLabel>
                      <FormControl>
                        <Textarea placeholder="Your residential address" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="currentSchool"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Current School/College</FormLabel>
                        <FormControl>
                          <Input placeholder="School or college name" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="currentClass"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Current Class</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select your current class" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="9">Class 9</SelectItem>
                            <SelectItem value="10">Class 10</SelectItem>
                            <SelectItem value="11">Class 11</SelectItem>
                            <SelectItem value="12">Class 12</SelectItem>
                            <SelectItem value="12_passed">Class 12 Passed</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="space-y-6">
                  <FormField
                    control={form.control}
                    name="examType"
                    render={({ field }) => (
                      <FormItem className="space-y-3">
                        <FormLabel>Exam Preparation</FormLabel>
                        <FormControl>
                          <RadioGroup
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                            className="flex flex-col space-y-1"
                          >
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="iit-jee" id="iit-jee" />
                              <FormLabel htmlFor="iit-jee" className="font-normal">
                                IIT JEE
                              </FormLabel>
                            </div>
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="neet" id="neet" />
                              <FormLabel htmlFor="neet" className="font-normal">
                                NEET
                              </FormLabel>
                            </div>
                          </RadioGroup>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="batchType"
                    render={({ field }) => (
                      <FormItem className="space-y-3">
                        <FormLabel>Batch Type</FormLabel>
                        <FormControl>
                          <RadioGroup
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                            className="flex flex-col space-y-1"
                          >
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="foundation" id="foundation" />
                              <FormLabel htmlFor="foundation" className="font-normal">
                                Foundation Batch (Class 11 & 12)
                              </FormLabel>
                            </div>
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="target" id="target" />
                              <FormLabel htmlFor="target" className="font-normal">
                                Target Batch (Intensive Course)
                              </FormLabel>
                            </div>
                          </RadioGroup>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="subjects"
                    render={() => (
                      <FormItem>
                        <div className="mb-4">
                          <FormLabel className="text-base">Subjects</FormLabel>
                          <FormDescription>
                            Select the subjects you want to enroll for
                          </FormDescription>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <FormField
                            control={form.control}
                            name="subjects"
                            render={({ field }) => {
                              return (
                                <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                                  <FormControl>
                                    <input
                                      type="checkbox"
                                      checked={field.value?.includes("physics")}
                                      onChange={(e) => {
                                        const value = "physics";
                                        const updatedValues = e.target.checked
                                          ? [...(field.value || []), value]
                                          : field.value?.filter((val) => val !== value) || [];
                                        field.onChange(updatedValues);
                                      }}
                                      className="h-4 w-4 mt-1"
                                    />
                                  </FormControl>
                                  <FormLabel className="font-normal cursor-pointer">
                                    Physics
                                  </FormLabel>
                                </FormItem>
                              );
                            }}
                          />
                          <FormField
                            control={form.control}
                            name="subjects"
                            render={({ field }) => {
                              return (
                                <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                                  <FormControl>
                                    <input
                                      type="checkbox"
                                      checked={field.value?.includes("chemistry")}
                                      onChange={(e) => {
                                        const value = "chemistry";
                                        const updatedValues = e.target.checked
                                          ? [...(field.value || []), value]
                                          : field.value?.filter((val) => val !== value) || [];
                                        field.onChange(updatedValues);
                                      }}
                                      className="h-4 w-4 mt-1"
                                    />
                                  </FormControl>
                                  <FormLabel className="font-normal cursor-pointer">
                                    Chemistry
                                  </FormLabel>
                                </FormItem>
                              );
                            }}
                          />
                          <FormField
                            control={form.control}
                            name="subjects"
                            render={({ field }) => {
                              return (
                                <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                                  <FormControl>
                                    <input
                                      type="checkbox"
                                      checked={field.value?.includes("mathematics")}
                                      onChange={(e) => {
                                        const value = "mathematics";
                                        const updatedValues = e.target.checked
                                          ? [...(field.value || []), value]
                                          : field.value?.filter((val) => val !== value) || [];
                                        field.onChange(updatedValues);
                                      }}
                                      className="h-4 w-4 mt-1"
                                    />
                                  </FormControl>
                                  <FormLabel className="font-normal cursor-pointer">
                                    Mathematics
                                  </FormLabel>
                                </FormItem>
                              );
                            }}
                          />
                          <FormField
                            control={form.control}
                            name="subjects"
                            render={({ field }) => {
                              return (
                                <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                                  <FormControl>
                                    <input
                                      type="checkbox"
                                      checked={field.value?.includes("biology")}
                                      onChange={(e) => {
                                        const value = "biology";
                                        const updatedValues = e.target.checked
                                          ? [...(field.value || []), value]
                                          : field.value?.filter((val) => val !== value) || [];
                                        field.onChange(updatedValues);
                                      }}
                                      className="h-4 w-4 mt-1"
                                    />
                                  </FormControl>
                                  <FormLabel className="font-normal cursor-pointer">
                                    Biology
                                  </FormLabel>
                                </FormItem>
                              );
                            }}
                          />
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="additionalInfo"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Additional Information</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Any additional information you'd like to share"
                          className="resize-none"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button 
                  type="submit" 
                  className="w-full bg-primary hover:bg-primary-dark"
                  disabled={mutation.isPending}
                >
                  {mutation.isPending ? "Submitting..." : "Submit Application"}
                </Button>
              </form>
            </Form>
          </div>
        </div>
      </section>
    </>
  );
};

export default AdmissionPage;
