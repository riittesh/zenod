import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import AssignmentCard from "@/components/assignments/AssignmentCard";
import HeroSection from "@/components/hero/HeroSection";
import { Helmet } from "react-helmet";
import { SITE_NAME } from "@/lib/constants";

type AssignmentType = "homework" | "classwork";
type Subject = "Physics" | "Chemistry" | "Mathematics" | "Biology";

interface Assignment {
  id: number;
  title: string;
  subject: Subject;
  dueDate: string;
  type: AssignmentType;
  googleClassroomLink: string;
}

const assignments: Assignment[] = [
  {
    id: 1,
    title: "Mechanics - Forces and Motion",
    subject: "Physics",
    dueDate: "2024-05-15",
    type: "homework",
    googleClassroomLink: "https://classroom.google.com"
  },
  {
    id: 2,
    title: "Organic Chemistry - Alkanes and Alkenes",
    subject: "Chemistry",
    dueDate: "2024-05-16",
    type: "homework",
    googleClassroomLink: "https://classroom.google.com"
  },
  {
    id: 3,
    title: "Calculus - Integration Techniques",
    subject: "Mathematics",
    dueDate: "2024-05-17",
    type: "homework",
    googleClassroomLink: "https://classroom.google.com"
  },
  {
    id: 4,
    title: "Electric Circuits - Problem Set",
    subject: "Physics",
    dueDate: "2024-05-14",
    type: "classwork",
    googleClassroomLink: "https://classroom.google.com"
  },
  {
    id: 5,
    title: "Inorganic Chemistry - Periodic Table",
    subject: "Chemistry",
    dueDate: "2024-05-13",
    type: "classwork",
    googleClassroomLink: "https://classroom.google.com"
  },
  {
    id: 6,
    title: "Human Physiology - Nervous System",
    subject: "Biology",
    dueDate: "2024-05-18",
    type: "homework",
    googleClassroomLink: "https://classroom.google.com"
  },
  {
    id: 7,
    title: "Cell Structure and Functions",
    subject: "Biology",
    dueDate: "2024-05-13",
    type: "classwork",
    googleClassroomLink: "https://classroom.google.com"
  },
  {
    id: 8,
    title: "Trigonometry - Practice Problems",
    subject: "Mathematics",
    dueDate: "2024-05-12",
    type: "classwork",
    googleClassroomLink: "https://classroom.google.com"
  }
];

const AssignmentPage = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [subjectFilter, setSubjectFilter] = useState<string>("all");

  const filterAssignments = (type: AssignmentType) => {
    return assignments
      .filter(assignment => assignment.type === type)
      .filter(assignment => 
        searchTerm === "" || 
        assignment.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        assignment.subject.toLowerCase().includes(searchTerm.toLowerCase())
      )
      .filter(assignment => 
        subjectFilter === "all" || 
        assignment.subject.toLowerCase() === subjectFilter.toLowerCase()
      );
  };

  const homeworkAssignments = filterAssignments("homework");
  const classworkAssignments = filterAssignments("classwork");

  return (
    <>
      <Helmet>
        <title>Assignments - {SITE_NAME}</title>
        <meta name="description" content="Access homework and classwork assignments for IIT JEE and NEET preparation at Numerical Expert." />
      </Helmet>

      <HeroSection
        title="Assignments & Worksheets"
        description="Access and submit your assignments through our integrated Google Classroom system."
        imageUrl="https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&q=80"
        showButtons={false}
      />

      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-bold text-neutral-900 font-montserrat">Your Assignments</h2>
            <p className="mt-2 text-lg text-neutral-600">
              Complete and submit your assignments through our Google Classroom integration
            </p>
          </div>

          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 space-y-4 md:space-y-0">
            <Select
              value={subjectFilter}
              onValueChange={setSubjectFilter}
            >
              <SelectTrigger className="w-full md:w-[180px]">
                <SelectValue placeholder="Filter by Subject" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Subjects</SelectItem>
                <SelectItem value="physics">Physics</SelectItem>
                <SelectItem value="chemistry">Chemistry</SelectItem>
                <SelectItem value="mathematics">Mathematics</SelectItem>
                <SelectItem value="biology">Biology</SelectItem>
              </SelectContent>
            </Select>
            
            <div className="w-full md:w-80">
              <Input
                placeholder="Search assignments..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full"
              />
            </div>
          </div>

          <Tabs defaultValue="homework" className="w-full">
            <TabsList className="grid w-full max-w-md mx-auto grid-cols-2 mb-8">
              <TabsTrigger value="homework">Homework</TabsTrigger>
              <TabsTrigger value="classwork">Classwork</TabsTrigger>
            </TabsList>
            
            <TabsContent value="homework">
              {homeworkAssignments.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {homeworkAssignments.map((assignment) => (
                    <AssignmentCard key={assignment.id} {...assignment} />
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <p className="text-neutral-500">No homework assignments found matching your criteria.</p>
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="classwork">
              {classworkAssignments.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {classworkAssignments.map((assignment) => (
                    <AssignmentCard key={assignment.id} {...assignment} />
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <p className="text-neutral-500">No classwork assignments found matching your criteria.</p>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </section>
    </>
  );
};

export default AssignmentPage;
