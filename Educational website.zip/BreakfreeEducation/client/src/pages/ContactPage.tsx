import ContactForm from "@/components/contact/ContactForm";
import ContactInfo from "@/components/contact/ContactInfo";
import HeroSection from "@/components/hero/HeroSection";
import { CONTACT } from "@/lib/constants";
import { Helmet } from "react-helmet";
import { SITE_NAME } from "@/lib/constants";

const ContactPage = () => {
  return (
    <>
      <Helmet>
        <title>Contact Us - {SITE_NAME}</title>
        <meta name="description" content="Get in touch with BreakFree Classes coaching institute for IIT JEE and NEET preparation." />
      </Helmet>

      <HeroSection
        title="Contact Us"
        description="Have questions? We're here to help you on your academic journey."
        imageUrl="https://images.unsplash.com/photo-1560438718-eb61ede255eb?auto=format&fit=crop&q=80"
        showButtons={false}
      />

      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-bold text-neutral-900 font-montserrat">Get in Touch</h2>
            <p className="mt-2 text-lg text-neutral-600">
              Have questions? We're here to help you on your academic journey.
            </p>
          </div>

          <div className="grid grid-cols-1 gap-8 md:grid-cols-2">
            <ContactInfo 
              phone={CONTACT.phone}
              branches={CONTACT.branches}
              instagram={CONTACT.instagram}
              openingHours={CONTACT.openingHours}
            />
            <ContactForm />
          </div>
        </div>
      </section>
    </>
  );
};

export default ContactPage;
