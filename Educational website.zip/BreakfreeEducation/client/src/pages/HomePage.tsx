import HeroSection from "@/components/hero/HeroSection";
import FeaturesSection from "@/components/home/FeaturesSection";
import CoursesSection from "@/components/home/CoursesSection";
import CTASection from "@/components/home/CTASection";
import { Helmet } from "react-helmet";
import { SITE_NAME, SITE_DESCRIPTION } from "@/lib/constants";

const HomePage = () => {
  return (
    <>
      <Helmet>
        <title>{SITE_NAME} - Excellence in IIT JEE & NEET Coaching</title>
        <meta name="description" content={SITE_DESCRIPTION} />
      </Helmet>
      <HeroSection
        title={<>Welcome to <span className="text-accent">BreakFree Classes</span></>}
        subtitle="Over 8+ Years of Excellence in Teaching"
        description="We focus on developing a strong foundation in concepts and problem-solving skills to help students excel in competitive examinations."
        imageUrl="/attached_assets/beautiful-girl-student-smiling-against-university-learning-education-concept-young-girl-student-smiling-against-university-cute-163165105.webp"
      />
      <FeaturesSection />
      <CoursesSection />
      <CTASection />
    </>
  );
};

export default HomePage;
