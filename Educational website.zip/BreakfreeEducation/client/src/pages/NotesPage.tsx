import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import SubjectCard from "@/components/notes/SubjectCard";
import HeroSection from "@/components/hero/HeroSection";
import { SUBJECT_TYPES } from "@/lib/constants";
import { Helmet } from "react-helmet";
import { SITE_NAME } from "@/lib/constants";

const NotesPage = () => {
  const [searchTerm, setSearchTerm] = useState("");

  const iitJeeSubjects = [
    {
      ...SUBJECT_TYPES.IIT_JEE.PHYSICS,
      category: "iit" as const,
      href: "/notes/iit-jee/physics"
    },
    {
      ...SUBJECT_TYPES.IIT_JEE.CHEMISTRY,
      category: "iit" as const,
      href: "/notes/iit-jee/chemistry"
    },
    {
      ...SUBJECT_TYPES.IIT_JEE.MATHEMATICS,
      category: "iit" as const,
      href: "/notes/iit-jee/mathematics"
    }
  ];

  const neetSubjects = [
    {
      ...SUBJECT_TYPES.NEET.PHYSICS,
      category: "neet" as const,
      href: "/notes/neet/physics"
    },
    {
      ...SUBJECT_TYPES.NEET.CHEMISTRY,
      category: "neet" as const,
      href: "/notes/neet/chemistry"
    },
    {
      ...SUBJECT_TYPES.NEET.BIOLOGY,
      category: "neet" as const,
      href: "/notes/neet/biology"
    }
  ];

  const filterSubjects = (subjects: typeof iitJeeSubjects) => {
    if (!searchTerm) return subjects;
    
    return subjects.filter(subject => 
      subject.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      subject.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      subject.chapters.some(chapter => 
        chapter.toLowerCase().includes(searchTerm.toLowerCase())
      )
    );
  };

  const filteredIITJEESubjects = filterSubjects(iitJeeSubjects);
  const filteredNEETSubjects = filterSubjects(neetSubjects);

  return (
    <>
      <Helmet>
        <title>Study Notes - {SITE_NAME}</title>
        <meta name="description" content="Access comprehensive study materials and notes for IIT JEE and NEET preparation at Numerical Expert." />
      </Helmet>

      <HeroSection
        title="Study Notes & Materials"
        description="Access comprehensive study materials organized by subject for your exam preparation."
        imageUrl="https://images.unsplash.com/photo-1532012197267-da84d127e765?auto=format&fit=crop&q=80"
        showButtons={false}
      />

      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-10 space-y-4 md:space-y-0">
            <div>
              <h2 className="text-3xl font-bold text-neutral-900 font-montserrat">Subject Notes</h2>
              <p className="mt-2 text-lg text-neutral-600">
                Browse through comprehensive notes for all subjects
              </p>
            </div>
            <div className="w-full md:w-80">
              <Input
                placeholder="Search for topics or subjects..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full"
              />
            </div>
          </div>

          <Tabs defaultValue="iit-jee" className="w-full">
            <TabsList className="grid w-full max-w-md mx-auto grid-cols-2 mb-8">
              <TabsTrigger value="iit-jee">IIT JEE</TabsTrigger>
              <TabsTrigger value="neet">NEET</TabsTrigger>
            </TabsList>
            
            <TabsContent value="iit-jee">
              {filteredIITJEESubjects.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredIITJEESubjects.map((subject, index) => (
                    <SubjectCard key={index} {...subject} />
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <p className="text-neutral-500">No subjects found matching your search.</p>
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="neet">
              {filteredNEETSubjects.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredNEETSubjects.map((subject, index) => (
                    <SubjectCard key={index} {...subject} />
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <p className="text-neutral-500">No subjects found matching your search.</p>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </section>
    </>
  );
};

export default NotesPage;
