import HeroSection from "@/components/hero/HeroSection";
import { DIRECTOR_INFO, CONTACT } from "@/lib/constants";
import { Helmet } from "react-helmet";
import { SITE_NAME } from "@/lib/constants";

const AboutPage = () => {
  return (
    <>
      <Helmet>
        <title>About Us - {SITE_NAME}</title>
        <meta name="description" content="Learn about BreakFree Classes and our director Sagar Manglam, a specialist for IIT JEE and NEET preparation." />
      </Helmet>

      <HeroSection
        title="About BreakFree Classes"
        description="Over 8+ years of excellence in teaching IIT JEE and NEET aspirants."
        imageUrl="https://images.unsplash.com/photo-1577896851231-70ef18881754?auto=format&fit=crop&q=80"
        showButtons={false}
      />

      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Director Section */}
          <div className="mb-16">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-neutral-900 font-montserrat">Director</h2>
              <h3 className="text-2xl font-bold text-primary mt-2">{DIRECTOR_INFO.name}</h3>
              <p className="text-lg text-neutral-700 mt-1">{DIRECTOR_INFO.title}</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-neutral-50 p-6 rounded-lg shadow-sm border border-neutral-200">
                <div className="aspect-[3/4] rounded-lg overflow-hidden">
                  <img 
                    src="/attached_assets/WhatsApp Image 2025-04-27 at 00.38.23_52e2a193.jpg"
                    alt="Director Sagar Manglam - Formal" 
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
              
              <div className="bg-neutral-50 p-6 rounded-lg shadow-sm border border-neutral-200">
                <div className="aspect-[3/4] rounded-lg overflow-hidden">
                  <img 
                    src="/attached_assets/WhatsApp Image 2025-04-27 at 00.41.02_716e2a4d.jpg"
                    alt="Director Sagar Manglam" 
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            </div>
            
            <div className="mt-8 bg-white p-6 rounded-lg shadow-sm border border-neutral-200">
              <p className="text-neutral-700 text-lg">
                {DIRECTOR_INFO.description}
              </p>
              <div className="mt-4 flex justify-center">
                <a 
                  href={`https://instagram.com/${CONTACT.instagram}`} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="inline-flex items-center text-primary hover:text-primary-dark"
                >
                  <i className="fab fa-instagram text-xl mr-2"></i>
                  @{CONTACT.instagram}
                </a>
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            {/* Our Story */}
            <div>
              <h2 className="text-3xl font-bold text-neutral-900 font-montserrat">Our Story</h2>
              <div className="mt-6 text-lg text-neutral-600 space-y-4">
                <p>
                  BreakFree Classes was founded with a vision to transform the way students approach competitive exams like IIT JEE and NEET. Our focus has always been on building strong conceptual understanding rather than rote learning.
                </p>
                <p>
                  Since our inception, we have helped thousands of students achieve their dreams of entering premier engineering and medical institutions across the country. Our teaching methodology emphasizes problem-solving techniques and analytical thinking.
                </p>
                <p>
                  We believe that every student has the potential to excel, and our job is to bring out that potential through personalized attention and guidance. Our small batch sizes ensure that each student receives the attention they need.
                </p>
              </div>
            </div>
            
            {/* Values and Contact */}
            <div>
              <div className="mb-10">
                <h3 className="text-xl font-semibold text-neutral-900 font-montserrat">Our Values</h3>
                <ul className="mt-4 space-y-2">
                  <li className="flex items-start">
                    <i className="fas fa-check-circle text-primary mt-1 mr-2"></i>
                    <span className="text-neutral-700">Excellence in education</span>
                  </li>
                  <li className="flex items-start">
                    <i className="fas fa-check-circle text-primary mt-1 mr-2"></i>
                    <span className="text-neutral-700">Student-centric approach</span>
                  </li>
                  <li className="flex items-start">
                    <i className="fas fa-check-circle text-primary mt-1 mr-2"></i>
                    <span className="text-neutral-700">Conceptual clarity over memorization</span>
                  </li>
                  <li className="flex items-start">
                    <i className="fas fa-check-circle text-primary mt-1 mr-2"></i>
                    <span className="text-neutral-700">Continuous improvement and innovation</span>
                  </li>
                </ul>
              </div>
              
              <div>
                <h3 className="text-xl font-semibold text-neutral-900 font-montserrat">Visit Us</h3>
                <div className="mt-4 space-y-2 text-neutral-600">
                  <p className="flex items-start">
                    <i className="fas fa-clock text-primary mt-1 mr-2"></i>
                    <span>{CONTACT.openingHours}</span>
                  </p>
                  <p className="flex items-start">
                    <i className="fas fa-phone text-primary mt-1 mr-2"></i>
                    <span>{CONTACT.phone}</span>
                  </p>
                  {CONTACT.branches.map((branch, index) => (
                    <p key={index} className="flex items-start">
                      <i className="fas fa-map-marker-alt text-primary mt-1 mr-2"></i>
                      <span>{branch.name}: {branch.address}</span>
                    </p>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default AboutPage;
